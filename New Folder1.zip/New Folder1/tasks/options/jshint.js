/**
 * Configure which files to run jshint on.
 *
 * Feel free to adjust the jshint rules in .jshintrc.  http://jshint.com/docs/options/
 */
module.exports = {
    options: {
        jshintrc: '.jshintrc'

    },
    src: [
        'public/scripts/**/*.js',
        '!public/scripts/google-api.js',
        '!public/scripts/modules/sample-module/MapCtrl.js',
	'!public/scripts/modules/sample-module/checkInCtrl.js'
	
	
    ],
    test: [
        'public/scripts/**/spec/*.js',
        'test/e2e/**/*.js'
    ]
};
