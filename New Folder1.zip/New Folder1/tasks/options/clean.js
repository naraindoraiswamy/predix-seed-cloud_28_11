/**
 * Configure cleanup tasks
 */
module.exports = {
    build: ['dist/www'],
    test: ['test-target/']
};
